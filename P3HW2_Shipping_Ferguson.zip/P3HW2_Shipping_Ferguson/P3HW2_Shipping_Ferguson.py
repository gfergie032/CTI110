# CTI 110
# P3HW2 Shipping Charges
# Gayon Ferguson
# November 13, 2018

# Weight of package per pound.
RateOne = 1.50
RateTwo = 3.00
RateThree = 4.00
RateFour = 4.75

# Ask for the weight of the packages.
packageWeight = float(input('Enter Weight of package: '))

# Multiply package weight by shipping cost.
if packageWeight <= 2:
    cost = packageWeight * RateOne
else:
    if packageWeight <= 6:
        cost = packageWeight * RateTwo
    else:
        if packageWeight <= 10:
             cost = packageWeight * RateThree
        else:
            if packageWeight > 10:
                   cost = packageWeight * RateFour
# Display shipping cost.
if packageWeight <= 0:
    Print('Not a valid weight')
else:
    if packageWeight <= 2:
        print('The cost to ship this package will be $', format(cost, ',.2f'))
    else:
        if packageWeight <= 6:
            print('The cost to ship this package will be $', format(cost, ',.2f'))
        else:
            if packageWeight <= 10:
                print('The cost to ship this package will be $', format(cost, ',.2f'))
            else:
                if packageWeight > 10:
                    print('The cost to ship this package will be $', format(cost, ',.2f'))
    
        

        



