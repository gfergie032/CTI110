# CTI 110
# P4HW3 Tuition Increase
# Gayon Ferguson
# November 24, 2018


# Tuition for full-time student.
# Increase by 3 percent each year for 5 years.
# Display projected semester tuition amount for next 5 years.


# Tuition for full-time student.
tuition = 8000   
increase = .03

# Get tuition for over next 5 years.
print ('Tuition increase over next 5 years\n')



# Display tuition cost for the next 5 years.
for year in range(5):
   amount = tuition * ( 1.0 + increase ) ** year
   print("Per Semester - Year {}: ${:,.2f}".format(year + 1, amount))
