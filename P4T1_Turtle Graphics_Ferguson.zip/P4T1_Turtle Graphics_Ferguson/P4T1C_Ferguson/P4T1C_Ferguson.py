# CTI 110
# P4T1C Snowflake (Windmill)
# Gayon Ferguson
# November 20, 2018


from turtle import Turtle

# Create the turtle on your screen.
# Turtle shape pen (takes string)
# Random pencolor.
# screen background color black.
t=Turtle()
t.screen.bgcolor("black")
t.colors=["blue","purple","red","yellow","orange","white"]
t.screen.tracer(2,-5)
t.speed(1000)

# Display four spinning windmill. 
def star(x,y):
    for b in range(1):
        t.right(36)
        for j in range(1): 
                t.left(45)
                for i in range(150): # or (1,2,3,4,5):
                    t.color(t.colors[i%6])
                    t.fd(i)
                    t.left(59)
                    t.penup()
                    t.goto(x,y)
                    t.pendown()
                    
# Four sets of widmill in four separate position.
star (-170,150)
star (140,200)
star (-170,-170)
star (140,-170)


t.screen.exitonclick()
t.screen.mainloop()
    
