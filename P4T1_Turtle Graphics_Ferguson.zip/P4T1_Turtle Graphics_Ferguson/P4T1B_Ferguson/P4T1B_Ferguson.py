# CTI 110
# P4T1B Initials
# Gayon Ferguson
# November 15, 2018

import turtle                           # Let you use the turtle. 
win = turtle.Screen()                   # Create the turtle on your screen.
t = turtle.Turtle()                     # Let you use the turtle to draw initial G & F.

t.pensize(4)            # increase pensize (takes integer)
t.pencolor("green")     # set pencolor (takes string)
t.shape("turtle")       # turtle shape pen (takes string)

# Create initial G.
t.penup()
t.goto(-150,150)
t.pendown()
t.forward(0)         
t.left(90)             
t.forward(50)
t.left(90)
t.forward(200)
t.left(90)
t.forward(280)
t.left(90)
t.forward(200)
t.left(90)
t.forward(100)
t.left(90)
t.forward(70)
t.penup()

# Create initial F.     
t.penup()
t.goto(100,200)
t.pendown()             
t.forward(200)
t.left(90)
t.forward(100)
t.left(90)
t.forward(75)
t.backward(75)
t.right(90)
t.forward(135)
t.forward(50)






