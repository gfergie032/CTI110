# CTI 110
# P4T1A Shapes
# Gayon Ferguson
# November 15, 2018


import turtle                           # Let you use the turtle. 
win = turtle.Screen()                   # Create the turtle on your screen.
t = turtle.Turtle()                     # Let you use the turtle to draw a triangle and a square.

# add some display options
# increase pensize (takes integer)
# set pencolor (takes string)
t.pensize(4)            
t.pencolor("skyblue")     
t.shape("turtle")

# Create triangle.
t.forward(150)          
t.left(120)            
t.forward(150)
t.left(120)
t.forward(150)


# Create Square.
t.left(30) 
t.forward(150)          
t.left(90)
t.forward(150)
t.left(90)
t.forward(150)
t.left(90)
t.forward(150)


# end commands
win.mainloop()  
