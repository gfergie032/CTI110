# CTI 110
# P4HW1 Budget Analysis
# Gayon Ferguson
# November 24, 2018


# Input the amount that he or she has budgeted.
# Enter each of his or her expenses for the month and keep a running total.
# Display the amount that the user is over or under budget.



expense = 0.0
budget = 0.0
difference = 0.0
expenseTotal = 0.0

total_expense = 0
keep_going = 'y'


# Enter a monthly budget.
budget = float(input("What is your budget for the month?"))
print("Please begin entering the amounts of each of your monthly expenses:")

# Ask the user to enter an expense.
while keep_going == 'y':
    expense = float(input("Monthly expense amount? $"))
    #*Having an issue keeping the expense running total at the end of the program?*
    total_expense = total_expense + expense
    keep_going = input("Do you have any other expenses? (Enter y for yes.)")

# Calculate budget total expenses.
if total_expense < budget:
    difference = budget - total_expense
    print("You were $", difference, " under budget.")

elif total_expense > budget:
    difference = total_expense - budget
    print("You were $", difference, " over budget.")

else:
    print("You were right on budget. Great Job!!!")

# To exit program.
input("Press enter to exit.")
