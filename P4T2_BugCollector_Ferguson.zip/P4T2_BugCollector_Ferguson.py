# CTI 110
# P4T2  Bug Collector
# Gayon Ferguson
# November 15, 2018

# Set total = 0
# for each of 7 days:
# input bugs collected for a day
# Add bugs collected to total
# Display total


# Initialize the accumulator.
total = 0

# Get the bugs collected for each day.
for day in range (1,6):
           print('Enter the bugs collected on day', day)
           bugs = int(input ())
           total += bugs

# Display the total bugs.
print('You collected a total of', total,'bug.')
                      
