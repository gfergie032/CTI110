# Celsius to Fahrenheit Temperature Converter.
# October 26, 2018
# CTI-110 P2HW1 - Celsius Fahrenheit Converter 
# Gayon Ferguson

# Converts Celsius temperatures.
celsius = float(input('Enter celcius temperature: '))

# Calculate celsius to Fahrenheit.
fahrenheit = (celsius * 9/5) + 32

# Display the temperature.
print(celsius, "degrees celsius is",fahrenheit,"fahrenheit.")
