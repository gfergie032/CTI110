# Python interpreter
# October 26, 2018
# CTI-110 Tutorial 1 - My First Python Program
# Gayon Feguson
print('This is a test of the Python interpreter')
