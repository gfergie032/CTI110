# CTI 110
# P4HW2 Celsius to Fahrenheit
# Gayon Ferguson
# November 23, 2018

# Display table of Cesius temperature 0 - 20.
# Convert temperature from calsius to Fahrenheit.

count = 0
celsius = 0
while (celsius <= 20):
    
# Display the temperature table from 0 - 20.
    print("Celsius:", celsius, "Fahrenheit:", count)
    celsius = celsius + 1
    count = celsius * 9/5+32


