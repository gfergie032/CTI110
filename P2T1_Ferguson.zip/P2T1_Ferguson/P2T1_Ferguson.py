# CTI 110
# M2T1
# Gayon Ferguson
# November 01, 2018

studentName="Gayon"
studentGPA="3.2"
studentAge=25
print("Hello", studentName)
print("Your GPA is", studentGPA)
print("and you are", studentAge) 

