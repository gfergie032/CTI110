# CTI 110
# P4LAB NestedLoops
# Gayon Ferguson
# November 15, 2018


for l in range (1,10):
    for k in range(l):
        print(l,end='')
print()


count = 1
for i in range(9):
    for j in range (-1, i):
        print (count, end = '')
    count = count + 1
    print (" ")
