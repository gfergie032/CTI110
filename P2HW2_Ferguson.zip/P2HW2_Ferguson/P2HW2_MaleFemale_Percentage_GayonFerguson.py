# Percentage of males and females in class.
# October 26, 2018
# CTI-110 P2HW2 - Male Female Percentage
# Gayon Ferguson

# Get the number of males register for class
number_males = int (input('Enter the number of males in class: '))

# Get the number of females register for class
number_females = int (input('Enter the number of females in class: '))

# Get the number of males and females register for class
student_total =  number_males + number_females

# Calculate the males as percent of total
males = number_males / student_total

# Calculate the males as percent of total
females = number_females / student_total

# Display number of males registered in a in class.
print ('Males is %', format(males, ',.2f'))

# Display number of females registered in a in class.
print ('Females is %', format(females, ',.2f'))
