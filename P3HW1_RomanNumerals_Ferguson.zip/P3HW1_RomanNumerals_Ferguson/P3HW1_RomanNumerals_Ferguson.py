# CTI 110
# P3HW1 Roman Numerals
# Gayon Ferguson
# November 06, 2018


# Real number chart from 1-10.
NumberOne = 1
NumberTwo = 2
NumberThree = 3
NumberFour = 4
NumberFive = 5
NumberSix = 6
NumberSeven = 7
NumberEight = 8
NumberNine = 9
NumberTen = 10
    
    
# Ask to input Regular number.
score = int(input('Enter Number: ',))  
    
# This program converts number from 1-10 to roman numerals.
if score == NumberOne:
            print('Roman Numeral is: I')
else:
    if score == NumberTwo:
             print('Your grade is: II')
    else:
        if score == NumberThree:
                 print('Your grade is: III')
        else:
            if score == NumberFour:
                     print('Your grade is: IV')
            else:
                if score == NumberFive:
                         print('Roman Numeral is: V')
                else:
                    if score == NumberSix:
                             print('Your grade is: VI')
                    else:
                        if score == NumberSeven:
                                 print('Your grade is: VII')
                        else:
                            if score == NumberEight:
                                     print('Your grade is: VIII')
                            else:
                                if score == NumberNine:
                                         print('Your grade is: IX')
                                else:
                                    if score == NumberTen:
                                             print('Your grade is: X')
                                    else:                                            
                                        if score > NumberTen:
                                                print('Values over 10 are not allowed')
                                                print('Its above the given range')
                                        else:
                                            if score < NumberOne:
                                                    print('Values is below given range')
                                                                         
